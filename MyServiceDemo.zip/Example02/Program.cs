﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;

namespace Example02
{
    public class MathDemo : IMathDemo
    {
        public int Add(int a, int b)
        {
            return a + b;
        }
    }
    class Program
    {
      
        static void Main(string[] args)
        {
            #region Bindings
            //WSHttpBinding binding = new WSHttpBinding();
            //Console.WriteLine("Info:");
            //Console.WriteLine($"\t{binding.GetType().Name}");
            //BindingElementCollection elements = binding.CreateBindingElements();
            //foreach (var item in elements)
            //{
            //    Console.WriteLine("Base binding: {0}", item.GetType().Name);
            //} 
            #endregion


        }
    }
}
