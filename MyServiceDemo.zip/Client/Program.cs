﻿using Example02;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            ChannelFactory<IMathDemo> channelFactory = new ChannelFactory<IMathDemo>(new WSHttpBinding(),
                                                                                    new EndpointAddress("http://127.0.0.1:9090/MathDemo"));
            IMathDemo channel = channelFactory.CreateChannel();
            int res = channel.Add(20,190);
            Console.WriteLine($"result: {res}");

            Console.ReadLine();
            channelFactory.Close();
        }
    }
}
